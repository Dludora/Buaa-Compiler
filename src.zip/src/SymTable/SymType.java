package SymTable;

public enum SymType {
    LVal,
    Func,
    Param
}