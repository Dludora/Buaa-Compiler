package mips;

public interface Assembly {
}
