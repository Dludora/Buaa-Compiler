package mips;

public interface Operand {
}
