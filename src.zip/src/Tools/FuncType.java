package Tools;

public enum FuncType {
    Int, Void
}
