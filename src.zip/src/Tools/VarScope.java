package Tools;

public enum VarScope {
    local,
    global
}
