package mid;

public enum RegType {
    i32,
    i32_p
}
